import React, { Suspense, useEffect } from "react";
import { Box, Page, useNavigate } from "zmp-ui";
import { Inquiry } from "./inquiry";
import { EntryActions } from "./entry-actions";
import { Welcome } from "./welcome";
import { Banner } from "./banner";
import { Categories } from "./categories";
import { Recommend } from "./recommend";
import { ProductList } from "./product-list";
import { clearApiSession, fetchMyProfile } from "services/api";

const HomePage: React.FunctionComponent = () => {
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    const demoEmail = (
      import.meta.env.VITE_API_DEMO_EMAIL || "customer@zauifood.local"
    )
      .trim()
      .toLowerCase();

    fetchMyProfile()
      .then((profile) => {
        if (!active) return;
        if ((profile.email || "").trim().toLowerCase() === demoEmail) {
          clearApiSession();
          navigate("/partner-onboarding?mode=register_customer&required=1", {
            replace: true,
          });
        }
      })
      .catch(() => {
        if (!active) return;
        navigate("/partner-onboarding?mode=register_customer&required=1", {
          replace: true,
        });
      });

    return () => {
      active = false;
    };
  }, [navigate]);

  return (
    <Page className="relative flex-1 flex flex-col" style={{ background: 'var(--tm-bg)' }}>
      <Welcome />
      <Box className="flex-1 overflow-auto">
        <Inquiry />
        <EntryActions />
        <Banner />
        <div className="tm-divider" />
        <Suspense>
          <Categories />
        </Suspense>
        <div className="tm-divider" />
        <Recommend />
        <div className="tm-divider" />
        <ProductList />
        <div style={{ height: 16 }} />
      </Box>
    </Page>
  );
};

export default HomePage;
