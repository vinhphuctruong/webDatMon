import { Router } from "express";
import { randomUUID } from "node:crypto";
import { StatusCodes } from "http-status-codes";
import { z } from "zod";
import { PartnerApplicationStatus, UserRole } from "@prisma/client";
import { env } from "../config/env";
import { prisma } from "../db/prisma";
import { asyncHandler } from "../lib/async-handler";
import { sendOtpEmail } from "../lib/email-service";
import { issueEmailOtp, verifyEmailOtp } from "../lib/email-otp";
import { HttpError } from "../lib/http-error";
import { requireAuth } from "../middlewares/auth";
import {
  hashToken,
  refreshTokenTtlMs,
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from "../utils/jwt";
import { comparePassword, hashPassword } from "../utils/password";

const authRouter = Router();

const registerSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email(),
  password: z.string().min(8).max(64),
  phone: z.string().min(8).max(20).optional(),
});

const registerCustomerSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email(),
  password: z.string().min(8).max(64),
  phone: z.string().min(8).max(20),
  otpCode: z.string().regex(/^\d{6}$/, "OTP phải gồm 6 chữ số"),
});

const registerStoreSchema = z.object({
  managerName: z.string().min(2).max(120),
  managerEmail: z.string().email(),
  managerPassword: z.string().min(8).max(64),
  managerPhone: z.string().min(8).max(20).optional(),
  storeName: z.string().min(2).max(160),
  storeAddress: z.string().min(4).max(300),
  etaMinutesMin: z.coerce.number().int().min(5).max(120).optional().default(20),
  etaMinutesMax: z.coerce.number().int().min(5).max(180).optional().default(35),
});

const registerDriverSchema = z.object({
  name: z.string().min(2).max(120),
  email: z.string().email(),
  password: z.string().min(8).max(64),
  phone: z.string().min(8).max(20).optional(),
  vehicleType: z.string().min(2).max(60),
  licensePlate: z.string().min(4).max(20),
});

const imageDataUrlSchema = z
  .string()
  .refine(
    (value) =>
      /^data:image\/(?:jpeg|jpg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(value),
    "Image must be JPEG, PNG or WEBP data URL",
  )
  .refine((value) => value.length >= 12_000, "Image quality is too low or file is invalid");

const registerDriverApplicationSchema = z.object({
  fullName: z.string().min(2).max(120),
  dateOfBirth: z.coerce.date(),
  email: z.string().email(),
  password: z.string().min(8).max(64),
  phone: z.string().min(8).max(20).optional(),
  vehicleType: z.string().min(2).max(60),
  licensePlate: z.string().min(4).max(20),
  portraitImageData: imageDataUrlSchema,
  idCardImageData: imageDataUrlSchema,
  driverLicenseImageData: imageDataUrlSchema,
  portraitQualityScore: z.coerce.number().min(110),
  idCardQualityScore: z.coerce.number().min(110),
  driverLicenseQualityScore: z.coerce.number().min(110),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(64),
});

const refreshSchema = z.object({
  refreshToken: z.string().min(10),
});

const requestEmailOtpSchema = z.object({
  email: z.string().email(),
});

const updateProfileSchema = z.object({
  name: z.string().min(2).max(120).optional(),
  email: z.string().email().optional(),
  phone: z.string().min(8).max(20).optional().nullable(),
  avatarUrl: z
    .string()
    .refine(
      (value) => /^data:image\/(?:jpeg|jpg|png|webp);base64,[A-Za-z0-9+/=]+$/i.test(value),
      "Avatar must be an uploaded JPEG, PNG or WEBP image",
    )
    .optional()
    .nullable(),
});

const changePasswordSchema = z.object({
  currentPassword: z.string().min(8).max(64),
  newPassword: z.string().min(8).max(64),
});

async function issueTokens(user: { id: string; email: string; role: UserRole }) {
  const accessToken = signAccessToken({
    sub: user.id,
    email: user.email,
    role: user.role,
  });

  const tokenId = randomUUID();
  const refreshToken = signRefreshToken({
    sub: user.id,
    email: user.email,
    role: user.role,
    tokenId,
  });

  await prisma.refreshToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(refreshToken),
      expiresAt: new Date(Date.now() + refreshTokenTtlMs()),
    },
  });

  return { accessToken, refreshToken };
}

function slugify(input: string): string {
  return input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

authRouter.post(
  "/register",
  asyncHandler(async (req, res) => {
    const payload = registerSchema.parse(req.body);

    const existed = await prisma.user.findUnique({
      where: { email: payload.email },
    });

    if (existed) {
      throw new HttpError(StatusCodes.CONFLICT, "Email already exists");
    }

    const passwordHash = await hashPassword(payload.password);

    const user = await prisma.user.create({
      data: {
        name: payload.name,
        email: payload.email,
        phone: payload.phone,
        passwordHash,
      },
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        role: true,
      },
    });

    const tokens = await issueTokens(user);

    res.status(StatusCodes.CREATED).json({
      user,
      tokens,
    });
  }),
);

authRouter.post(
  "/register/customer",
  asyncHandler(async (req, res) => {
    const payload = registerCustomerSchema.parse(req.body);
    const normalizedEmail = payload.email.trim().toLowerCase();
    const normalizedPhone = payload.phone.trim();

    const existed = await prisma.user.findUnique({
      where: { email: normalizedEmail },
    });

    if (existed) {
      throw new HttpError(StatusCodes.CONFLICT, "Email already exists");
    }

    const verified = verifyEmailOtp(normalizedEmail, payload.otpCode);
    if (!verified.ok) {
      throw new HttpError(StatusCodes.BAD_REQUEST, verified.message);
    }

    const passwordHash = await hashPassword(payload.password);

    const user = await prisma.user.create({
      data: {
        name: payload.name.trim(),
        email: normalizedEmail,
        phone: normalizedPhone,
        passwordHash,
        role: UserRole.CUSTOMER,
      },
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        role: true,
      },
    });

    const tokens = await issueTokens(user);

    res.status(StatusCodes.CREATED).json({
      user,
      tokens,
    });
  }),
);

authRouter.post(
  "/email-otp/request",
  asyncHandler(async (req, res) => {
    const payload = requestEmailOtpSchema.parse(req.body);
    const normalizedEmail = payload.email.trim().toLowerCase();

    const existed = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      select: { id: true },
    });

    if (existed) {
      throw new HttpError(StatusCodes.CONFLICT, "Email đã tồn tại, vui lòng dùng email khác");
    }

    const otp = issueEmailOtp(normalizedEmail);

    let sentByEmail = false;
    let emailDeliveryError: unknown;
    try {
      const result = await sendOtpEmail({
        toEmail: normalizedEmail,
        otpCode: otp.code,
        expiresInSeconds: otp.expiresInSeconds,
      });
      sentByEmail = result.sent;
    } catch (error) {
      emailDeliveryError = error;
      console.error("[auth][email-otp] Failed to send OTP email", error);
      if (env.NODE_ENV === "production") {
        throw new HttpError(
          StatusCodes.INTERNAL_SERVER_ERROR,
          "Khong gui duoc OTP qua email. Vui long thu lai sau.",
        );
      }
    }

    if (!sentByEmail) {
      if (env.NODE_ENV === "production") {
        throw new HttpError(
          StatusCodes.INTERNAL_SERVER_ERROR,
          "He thong OTP email chua duoc cau hinh.",
        );
      }
      console.log(
        `[auth][email-otp][dev-fallback] ${normalizedEmail} => ${otp.code} (expires in ${otp.expiresInSeconds}s)${emailDeliveryError ? " due to email delivery error" : ""}`,
      );
    }

    res.json({
      message: sentByEmail
        ? "Da gui ma OTP den email. Vui long kiem tra hop thu."
        : emailDeliveryError
          ? "Khong gui duoc OTP qua email. Da chuyen sang che do local, vui long dung debugOtp de test."
          : "OTP da duoc tao (che do local). Vui long dung debugOtp de test.",
      expiresInSeconds: otp.expiresInSeconds,
      retryAfterSeconds: otp.retryAfterSeconds,
      ...(env.NODE_ENV === "production" ? {} : { debugOtp: otp.code }),
    });
  }),
);

authRouter.post(
  "/register/store",
  asyncHandler(async (req, res) => {
    const payload = registerStoreSchema.parse(req.body);

    if (payload.etaMinutesMin > payload.etaMinutesMax) {
      throw new HttpError(
        StatusCodes.BAD_REQUEST,
        "etaMinutesMin must be less than or equal etaMinutesMax",
      );
    }

    const existed = await prisma.user.findUnique({
      where: { email: payload.managerEmail },
    });

    if (existed) {
      throw new HttpError(StatusCodes.CONFLICT, "Manager email already exists");
    }

    const passwordHash = await hashPassword(payload.managerPassword);

    const result = await prisma.$transaction(async (tx) => {
      const manager = await tx.user.create({
        data: {
          name: payload.managerName,
          email: payload.managerEmail,
          phone: payload.managerPhone,
          passwordHash,
          role: UserRole.STORE_MANAGER,
        },
        select: {
          id: true,
          email: true,
          name: true,
          avatarUrl: true,
          role: true,
        },
      });

      const store = await tx.store.create({
        data: {
          name: payload.storeName,
          slug: `${slugify(payload.storeName)}-${Date.now()}`,
          address: payload.storeAddress,
          etaMinutesMin: payload.etaMinutesMin,
          etaMinutesMax: payload.etaMinutesMax,
          isOpen: false,
          managerId: manager.id,
        },
        select: {
          id: true,
          name: true,
          address: true,
          isOpen: true,
        },
      });

      return { manager, store };
    });

    const tokens = await issueTokens(result.manager);

    res.status(StatusCodes.CREATED).json({
      user: result.manager,
      store: result.store,
      tokens,
      message:
        "Store account created. Your store is pending activation and is currently closed by default.",
    });
  }),
);

authRouter.post(
  "/register/driver",
  asyncHandler(async (req, res) => {
    const payload = registerDriverSchema.parse(req.body);

    const [emailExisted, plateExisted] = await Promise.all([
      prisma.user.findUnique({
        where: { email: payload.email },
      }),
      prisma.driverProfile.findUnique({
        where: { licensePlate: payload.licensePlate },
      }),
    ]);

    if (emailExisted) {
      throw new HttpError(StatusCodes.CONFLICT, "Email already exists");
    }

    if (plateExisted) {
      throw new HttpError(StatusCodes.CONFLICT, "License plate already exists");
    }

    const passwordHash = await hashPassword(payload.password);

    const user = await prisma.user.create({
      data: {
        name: payload.name,
        email: payload.email,
        phone: payload.phone,
        passwordHash,
        role: UserRole.DRIVER,
        driverProfile: {
          create: {
            vehicleType: payload.vehicleType,
            licensePlate: payload.licensePlate,
            isOnline: false,
          },
        },
      },
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        role: true,
      },
    });

    const tokens = await issueTokens(user);

    res.status(StatusCodes.CREATED).json({
      user,
      tokens,
    });
  }),
);

authRouter.post(
  "/partner/driver-application",
  asyncHandler(async (req, res) => {
    const payload = registerDriverApplicationSchema.parse(req.body);
    const normalizedEmail = payload.email.trim().toLowerCase();
    const normalizedPlate = payload.licensePlate.trim().toUpperCase();

    const minAdultAge = 18;
    const ageMs = Date.now() - payload.dateOfBirth.getTime();
    const ageYears = ageMs / (365.25 * 24 * 60 * 60 * 1000);
    if (ageYears < minAdultAge) {
      throw new HttpError(StatusCodes.BAD_REQUEST, "Driver applicant must be at least 18 years old");
    }

    const [emailExisted, plateExisted, pendingByEmail, pendingByPlate] = await Promise.all([
      prisma.user.findUnique({
        where: { email: normalizedEmail },
        select: { id: true },
      }),
      prisma.driverProfile.findUnique({
        where: { licensePlate: normalizedPlate },
        select: { id: true },
      }),
      prisma.driverApplication.findFirst({
        where: {
          email: normalizedEmail,
          status: PartnerApplicationStatus.PENDING,
        },
        select: { id: true },
      }),
      prisma.driverApplication.findFirst({
        where: {
          licensePlate: normalizedPlate,
          status: PartnerApplicationStatus.PENDING,
        },
        select: { id: true },
      }),
    ]);

    if (emailExisted || pendingByEmail) {
      throw new HttpError(StatusCodes.CONFLICT, "Email already exists or has pending application");
    }

    if (plateExisted || pendingByPlate) {
      throw new HttpError(StatusCodes.CONFLICT, "License plate already exists or is pending review");
    }

    const passwordHash = await hashPassword(payload.password);

    const application = await prisma.driverApplication.create({
      data: {
        fullName: payload.fullName,
        dateOfBirth: payload.dateOfBirth,
        email: normalizedEmail,
        phone: payload.phone,
        passwordHash,
        vehicleType: payload.vehicleType,
        licensePlate: normalizedPlate,
        portraitImageData: payload.portraitImageData,
        idCardImageData: payload.idCardImageData,
        driverLicenseImageData: payload.driverLicenseImageData,
        portraitQualityScore: payload.portraitQualityScore,
        idCardQualityScore: payload.idCardQualityScore,
        driverLicenseQualityScore: payload.driverLicenseQualityScore,
        status: PartnerApplicationStatus.PENDING,
      },
      select: {
        id: true,
        status: true,
        createdAt: true,
      },
    });

    res.status(StatusCodes.CREATED).json({
      data: application,
      message: "Driver application submitted and waiting for admin approval",
    });
  }),
);

authRouter.post(
  "/login",
  asyncHandler(async (req, res) => {
    const payload = loginSchema.parse(req.body);

    const user = await prisma.user.findUnique({
      where: { email: payload.email },
    });

    if (!user) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Invalid email or password");
    }

    const isMatched = await comparePassword(payload.password, user.passwordHash);
    if (!isMatched) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Invalid email or password");
    }

    const tokens = await issueTokens({
      id: user.id,
      email: user.email,
      role: user.role,
    });

    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
      },
      tokens,
    });
  }),
);

authRouter.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const userId = req.user?.id;
    if (!userId) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Unauthorized");
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatarUrl: true,
        role: true,
        createdAt: true,
      },
    });

    if (!user) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "User not found");
    }

    res.json(user);
  }),
);

authRouter.patch(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const userId = req.user?.id;
    if (!userId) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Unauthorized");
    }

    const payload = updateProfileSchema.parse(req.body);

    if (
      payload.name === undefined &&
      payload.email === undefined &&
      payload.phone === undefined &&
      payload.avatarUrl === undefined
    ) {
      throw new HttpError(StatusCodes.BAD_REQUEST, "No profile fields provided");
    }

    const nextEmail = payload.email?.trim().toLowerCase();
    const nextPhone = payload.phone === undefined ? undefined : payload.phone?.trim() || null;

    const [emailExisted, phoneExisted] = await Promise.all([
      nextEmail
        ? prisma.user.findFirst({
            where: {
              email: nextEmail,
              id: { not: userId },
            },
            select: { id: true },
          })
        : Promise.resolve(null),
      nextPhone
        ? prisma.user.findFirst({
            where: {
              phone: nextPhone,
              id: { not: userId },
            },
            select: { id: true },
          })
        : Promise.resolve(null),
    ]);

    if (emailExisted) {
      throw new HttpError(StatusCodes.CONFLICT, "Email already exists");
    }

    if (phoneExisted) {
      throw new HttpError(StatusCodes.CONFLICT, "Phone already exists");
    }

    const updated = await prisma.user.update({
      where: { id: userId },
      data: {
        ...(payload.name !== undefined ? { name: payload.name.trim() } : {}),
        ...(nextEmail !== undefined ? { email: nextEmail } : {}),
        ...(nextPhone !== undefined ? { phone: nextPhone } : {}),
        ...(payload.avatarUrl !== undefined
          ? { avatarUrl: payload.avatarUrl?.trim() || null }
          : {}),
      },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatarUrl: true,
        role: true,
        createdAt: true,
      },
    });

    res.json({
      data: updated,
      message: "Profile updated successfully",
    });
  }),
);

authRouter.patch(
  "/change-password",
  requireAuth,
  asyncHandler(async (req, res) => {
    const userId = req.user?.id;
    if (!userId) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Unauthorized");
    }

    const payload = changePasswordSchema.parse(req.body);
    if (payload.currentPassword === payload.newPassword) {
      throw new HttpError(
        StatusCodes.BAD_REQUEST,
        "New password must be different from current password",
      );
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, passwordHash: true },
    });

    if (!user) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "User not found");
    }

    const matched = await comparePassword(payload.currentPassword, user.passwordHash);
    if (!matched) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Current password is incorrect");
    }

    const newHash = await hashPassword(payload.newPassword);

    await prisma.$transaction([
      prisma.user.update({
        where: { id: userId },
        data: { passwordHash: newHash },
      }),
      prisma.refreshToken.updateMany({
        where: {
          userId,
          revokedAt: null,
        },
        data: {
          revokedAt: new Date(),
        },
      }),
    ]);

    res.json({
      message: "Password changed successfully. Please login again.",
    });
  }),
);

authRouter.post(
  "/refresh",
  asyncHandler(async (req, res) => {
    const payload = refreshSchema.parse(req.body);

    let decoded;
    try {
      decoded = verifyRefreshToken(payload.refreshToken);
    } catch (_error) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Invalid refresh token");
    }

    const tokenHash = hashToken(payload.refreshToken);

    const persisted = await prisma.refreshToken.findUnique({
      where: { tokenHash },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            role: true,
            name: true,
            avatarUrl: true,
          },
        },
      },
    });

    if (!persisted || persisted.revokedAt || persisted.expiresAt < new Date()) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Refresh token is expired or revoked");
    }

    if (persisted.userId !== decoded.sub) {
      throw new HttpError(StatusCodes.UNAUTHORIZED, "Refresh token mismatch");
    }

    await prisma.refreshToken.update({
      where: { id: persisted.id },
      data: { revokedAt: new Date() },
    });

    const tokens = await issueTokens({
      id: persisted.user.id,
      email: persisted.user.email,
      role: persisted.user.role,
    });

    res.json({
      user: persisted.user,
      tokens,
    });
  }),
);

authRouter.post(
  "/logout",
  asyncHandler(async (req, res) => {
    const payload = refreshSchema.parse(req.body);

    await prisma.refreshToken.updateMany({
      where: {
        tokenHash: hashToken(payload.refreshToken),
        revokedAt: null,
      },
      data: {
        revokedAt: new Date(),
      },
    });

    res.status(StatusCodes.NO_CONTENT).send();
  }),
);

export default authRouter;
